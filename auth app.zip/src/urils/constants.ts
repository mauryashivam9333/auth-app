export const CONSTANTS = {
  DEFAULT_INITIAL_VALUES: {
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  },
};
