export { default as PowerOffIcon } from "./fa-power-off";
